package com.example.stockspring.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.stockspring.dao.CompanyDao;
import com.example.stockspring.dao.IpoDao;
import com.example.stockspring.dao.StockPriceDao;
import com.example.stockspring.model.Company;
import com.example.stockspring.model.IpoPlanned;
import com.example.stockspring.model.StockPriceDetails;

@RestController
public class RestContollerCompany {
@Autowired
CompanyDao companydao;
@Autowired
StockPriceDao stockpricedao;
@Autowired
IpoDao ipodao;
@GetMapping("/companysectorlist")
List<Company> sectorList()
{
	return companydao.findBySectorId(1);
}
@GetMapping("/companystockpricelist/{date1}/{date2}")
List<StockPriceDetails> stockpriceList(@PathVariable("date1") Date date1,@PathVariable("date2") Date date2)
{
	return stockpricedao.findBycompanycode(date1,date2);
}
@GetMapping("/companyipolist")
List<IpoPlanned> ipoList()
{
	return ipodao.findBycompanycode(3);
}
@GetMapping("/company/pattern/{name}")
List<Company> findNameWithPattern(@PathVariable("name") String name)
{
	return companydao.findNameWithPattern(name);
}
}
