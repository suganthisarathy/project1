package com.example.stockspring.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "company")
public class Company {
	@Id
	@Column(name = "company_code")
	private int companyId;
	@NotEmpty(message = "please enter username")
	@Pattern(regexp = "[a-z]{4,10}", message = "Please enter 4-10 small case character")
	@Column(name = "company_Name")
	private String companyName;
	@NotNull(message = "please enter turnover")
	@Column(name = "turnover")
	private BigDecimal turnover;
	@NotEmpty(message = "please enter CEO name")
	@Pattern(regexp = "[a-z]{4,10}", message = "Please enter 4-10 small case character")
	@Column(name = "ceo")
	private String CEO;
	@NotEmpty(message = "please enter Board Of Directors")
	@Pattern(regexp = "[a-z]{4,10}", message = "Please enter 4-6 small case character")
	@Column(name = "boardofdirectors")
	private String boardOfDirectors;
	@NotNull(message = "please enter SectorId")
	@Column(name = "sector_id")
	private Integer sectorId;
	@NotEmpty(message = "please enter BreifWriteUp")
	@Pattern(regexp = "[a-z]{4,10}", message = "Please enter 4-6 small case character")
	@Column(name = "breifwriteup")
	private String briefWriteUp;
	@NotNull(message = "please enter StockCode")
	@Column(name = "stock_Code")
	private Integer stockCode;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public BigDecimal getTurnover() {
		return turnover;
	}

	public void setTurnover(BigDecimal turnover) {
		this.turnover = turnover;
	}

	public String getCEO() {
		return CEO;
	}

	public void setCEO(String cEO) {
		CEO = cEO;
	}

	public Integer getSectorId() {
		return sectorId;
	}

	public void setSectorId(Integer sectorId) {
		this.sectorId = sectorId;
	}

	public String getBriefWriteUp() {
		return briefWriteUp;
	}

	public void setBriefWriteUp(String briefWriteUp) {
		this.briefWriteUp = briefWriteUp;
	}

	public Integer getStockCode() {
		return stockCode;
	}

	public void setStockCode(Integer stockCode) {
		this.stockCode = stockCode;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}

	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}

}
