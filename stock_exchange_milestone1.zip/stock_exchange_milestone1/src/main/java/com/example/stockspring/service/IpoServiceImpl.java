package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.stockspring.dao.IpoDao;
import com.example.stockspring.model.IpoPlanned;
import com.example.stockspring.model.StockExchange;
@Service
public class IpoServiceImpl implements IpoService {
	@Autowired
	private IpoDao ipoDao;
	@Override
	public IpoPlanned insertIpo(IpoPlanned ipo) throws SQLException {
		// TODO Auto-generated method stub
		return ipoDao.save(ipo);
	}

	@Override
	public IpoPlanned updateIpo(IpoPlanned ipo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<IpoPlanned> getIpoList() throws Exception {
		// TODO Auto-generated method stub
		return ipoDao.findAll();
	}

}
