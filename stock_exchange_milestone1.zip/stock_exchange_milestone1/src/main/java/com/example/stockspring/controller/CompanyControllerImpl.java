package com.example.stockspring.controller;

import java.sql.SQLException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.model.Company;
import com.example.stockspring.service.CompanyService;

@Controller
public class CompanyControllerImpl implements CompanyController{

	
	@Autowired
	private CompanyService companyService;
	
	
	
	
	@RequestMapping(value = "/addCompany", method = RequestMethod.POST)
	public String insertCompany(@ModelAttribute("e1")@Valid Company company,BindingResult result,Model model) throws SQLException {
		if(result.hasErrors()){
			System.out.println("errors");
			System.out.println(result.getAllErrors());
			model.addAttribute("e1",company );
			return "NewCompany";
		}
		companyService.insertCompany(company);
		return "redirect:/companyList";	
	}

	@Override
	public Company updateCompany(Company company) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@RequestMapping(path="/companyList")
	public ModelAndView getCompanyList() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("ManageCompanies");
		mv.addObject("companyList",companyService.getCompanyList());
		return mv;
	}
	@RequestMapping(value = "/addCompany", method = RequestMethod.GET)
	public String getEmployeeForm(ModelMap model) {
		System.out.println("add employee");
		Company e=new Company();
		//e.setEmail("sdfsf");
	//	e.setSalary(4564.56f);
		model.addAttribute("e1", e);
		return "NewCompany";
		
	}
	
	// try
	
	
}