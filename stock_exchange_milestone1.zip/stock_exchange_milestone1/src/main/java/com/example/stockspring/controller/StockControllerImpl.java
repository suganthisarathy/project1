package com.example.stockspring.controller;

import java.sql.SQLException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.example.stockspring.model.StockExchange;

import com.example.stockspring.service.StockService;
@Controller
public class StockControllerImpl implements StockController {

	@Autowired
	private StockService stockService;
	
	
	
	
	@RequestMapping(value = "/addStock", method = RequestMethod.POST)
	public String insertCompany(@ModelAttribute("s1")@Valid StockExchange stock,BindingResult result,Model model) throws SQLException {
		if(result.hasErrors()){
			System.out.println("errors");
			System.out.println(result.getAllErrors());
			model.addAttribute("s1",stock );
			return "StockExchange";
		}
		stockService.insertStock(stock);
		return "redirect:/stockList";	
	}

	
	public StockExchange updateStock(StockExchange stock) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@RequestMapping(path="/stockList")
	public ModelAndView getStockList() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("StockList");
		mv.addObject("stockList",stockService.getStockList());
		return mv;
	}
	@RequestMapping(value = "/addStock", method = RequestMethod.GET)
	public String getStockForm(ModelMap model) {
		//System.out.println("add employee");
		StockExchange s=new StockExchange();
		//e.setEmail("sdfsf");
	//	e.setSalary(4564.56f);
		model.addAttribute("s1", s);
		return "StockExchange";
		
	}

}
